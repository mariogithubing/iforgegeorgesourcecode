
package net.mcreator.iforgegorege.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;

import net.mcreator.iforgegorege.entity.FloppaEntity;
import net.mcreator.iforgegorege.client.model.Modelcustom_model;

public class FloppaRenderer extends MobRenderer<FloppaEntity, Modelcustom_model<FloppaEntity>> {
	public FloppaRenderer(EntityRendererProvider.Context context) {
		super(context, new Modelcustom_model(context.bakeLayer(Modelcustom_model.LAYER_LOCATION)), 0.5f);
	}

	@Override
	public ResourceLocation getTextureLocation(FloppaEntity entity) {
		return new ResourceLocation("i_forge_gorege:textures/texture.png");
	}
}
