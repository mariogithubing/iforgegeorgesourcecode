
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.iforgegorege.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.BlockItem;

import net.mcreator.iforgegorege.item.WalmartObsidianPickaxeItem;
import net.mcreator.iforgegorege.item.SmartItem;
import net.mcreator.iforgegorege.item.RocketlauncherItem;
import net.mcreator.iforgegorege.item.PurpleBeanItem;
import net.mcreator.iforgegorege.item.NutgamingItem;
import net.mcreator.iforgegorege.item.LevodidItem;
import net.mcreator.iforgegorege.item.LeminigunItem;
import net.mcreator.iforgegorege.item.IphoneItem;
import net.mcreator.iforgegorege.item.GodBeansItem;
import net.mcreator.iforgegorege.item.FlashlightItem;
import net.mcreator.iforgegorege.item.BorgirItem;
import net.mcreator.iforgegorege.item.BedrockPickItem;
import net.mcreator.iforgegorege.item.BedrockArmorItem;
import net.mcreator.iforgegorege.item.BeansItem;
import net.mcreator.iforgegorege.item.ActualObsidianPaxelItem;
import net.mcreator.iforgegorege.IForgeGoregeMod;

public class IForgeGoregeModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, IForgeGoregeMod.MODID);
	public static final RegistryObject<Item> FLASHLIGHT = REGISTRY.register("flashlight", () -> new FlashlightItem());
	public static final RegistryObject<Item> SUN = block(IForgeGoregeModBlocks.SUN, CreativeModeTab.TAB_BUILDING_BLOCKS);
	public static final RegistryObject<Item> WALMART_OBSIDIAN_PICKAXE = REGISTRY.register("walmart_obsidian_pickaxe",
			() -> new WalmartObsidianPickaxeItem());
	public static final RegistryObject<Item> LEMINIGUN = REGISTRY.register("leminigun", () -> new LeminigunItem());
	public static final RegistryObject<Item> NUTGAMING_BUCKET = REGISTRY.register("nutgaming_bucket", () -> new NutgamingItem());
	public static final RegistryObject<Item> IPHONE = REGISTRY.register("iphone", () -> new IphoneItem());
	public static final RegistryObject<Item> ACTUAL_OBSIDIAN_PAXEL = REGISTRY.register("actual_obsidian_paxel", () -> new ActualObsidianPaxelItem());
	public static final RegistryObject<Item> LEVODID = REGISTRY.register("levodid", () -> new LevodidItem());
	public static final RegistryObject<Item> BEDROCK_STAIRS = block(IForgeGoregeModBlocks.BEDROCK_STAIRS, IForgeGoregeModTabs.TAB_IFGBLOCKS);
	public static final RegistryObject<Item> BEDROCK_PICK = REGISTRY.register("bedrock_pick", () -> new BedrockPickItem());
	public static final RegistryObject<Item> BEDROCK_ARMOR_HELMET = REGISTRY.register("bedrock_armor_helmet", () -> new BedrockArmorItem.Helmet());
	public static final RegistryObject<Item> BEDROCK_ARMOR_CHESTPLATE = REGISTRY.register("bedrock_armor_chestplate",
			() -> new BedrockArmorItem.Chestplate());
	public static final RegistryObject<Item> BEDROCK_ARMOR_LEGGINGS = REGISTRY.register("bedrock_armor_leggings",
			() -> new BedrockArmorItem.Leggings());
	public static final RegistryObject<Item> BEDROCK_ARMOR_BOOTS = REGISTRY.register("bedrock_armor_boots", () -> new BedrockArmorItem.Boots());
	public static final RegistryObject<Item> JELLYBEAN = REGISTRY.register("jellybean_spawn_egg",
			() -> new ForgeSpawnEggItem(IForgeGoregeModEntities.JELLYBEAN, -3407668, -65332,
					new Item.Properties().tab(IForgeGoregeModTabs.TAB_EXPERIMENTAL)));
	public static final RegistryObject<Item> SMART = REGISTRY.register("smart", () -> new SmartItem());
	public static final RegistryObject<Item> ROCKETLAUNCHER = REGISTRY.register("rocketlauncher", () -> new RocketlauncherItem());
	public static final RegistryObject<Item> PURPLE_BEAN = REGISTRY.register("purple_bean", () -> new PurpleBeanItem());
	public static final RegistryObject<Item> DONT = block(IForgeGoregeModBlocks.DONT, IForgeGoregeModTabs.TAB_IFGBLOCKS);
	public static final RegistryObject<Item> BEANS = REGISTRY.register("beans", () -> new BeansItem());
	public static final RegistryObject<Item> GOD_BEANS = REGISTRY.register("god_beans", () -> new GodBeansItem());
	public static final RegistryObject<Item> FLOPPA = REGISTRY.register("floppa_spawn_egg",
			() -> new ForgeSpawnEggItem(IForgeGoregeModEntities.FLOPPA, -1, -1, new Item.Properties().tab(IForgeGoregeModTabs.TAB_ITEMS)));
	public static final RegistryObject<Item> BORGIR = REGISTRY.register("borgir", () -> new BorgirItem());

	private static RegistryObject<Item> block(RegistryObject<Block> block, CreativeModeTab tab) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties().tab(tab)));
	}
}
