
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.iforgegorege.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;

import java.util.Map;
import java.util.HashMap;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class IForgeGoregeModSounds {
	public static Map<ResourceLocation, SoundEvent> REGISTRY = new HashMap<>();
	static {
		REGISTRY.put(new ResourceLocation("i_forge_gorege", "unfunny"), new SoundEvent(new ResourceLocation("i_forge_gorege", "unfunny")));
		REGISTRY.put(new ResourceLocation("i_forge_gorege", "smartrace"), new SoundEvent(new ResourceLocation("i_forge_gorege", "smartrace")));
		REGISTRY.put(new ResourceLocation("i_forge_gorege", "burenyuu"), new SoundEvent(new ResourceLocation("i_forge_gorege", "burenyuu")));
	}

	@SubscribeEvent
	public static void registerSounds(RegistryEvent.Register<SoundEvent> event) {
		for (Map.Entry<ResourceLocation, SoundEvent> sound : REGISTRY.entrySet())
			event.getRegistry().register(sound.getValue().setRegistryName(sound.getKey()));
	}
}
