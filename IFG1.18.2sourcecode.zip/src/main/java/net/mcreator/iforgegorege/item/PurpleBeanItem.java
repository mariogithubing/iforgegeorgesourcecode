
package net.mcreator.iforgegorege.item;

import net.minecraft.world.item.UseAnim;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;

import net.mcreator.iforgegorege.init.IForgeGoregeModTabs;

public class PurpleBeanItem extends Item {
	public PurpleBeanItem() {
		super(new Item.Properties().tab(IForgeGoregeModTabs.TAB_EXPERIMENTAL).stacksTo(64).rarity(Rarity.COMMON));
	}

	@Override
	public UseAnim getUseAnimation(ItemStack itemstack) {
		return UseAnim.EAT;
	}

	@Override
	public int getUseDuration(ItemStack itemstack) {
		return 0;
	}
}
