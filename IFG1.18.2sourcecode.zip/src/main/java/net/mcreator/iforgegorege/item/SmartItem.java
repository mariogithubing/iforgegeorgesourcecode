
package net.mcreator.iforgegorege.item;

import net.minecraft.world.item.RecordItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;

import net.mcreator.iforgegorege.init.IForgeGoregeModTabs;
import net.mcreator.iforgegorege.init.IForgeGoregeModSounds;

public class SmartItem extends RecordItem {
	public SmartItem() {
		super(0, IForgeGoregeModSounds.REGISTRY.get(new ResourceLocation("i_forge_gorege:smartrace")),
				new Item.Properties().tab(IForgeGoregeModTabs.TAB_ITEMS).stacksTo(1).rarity(Rarity.RARE));
	}
}
